'use server'

const getUserAuthenticated = (user) => {

}

const getUsers = () =>{
        
}
export { getUsers, getUserAuthenticated };